# CampusHub
A demo college web app (front-end only) with roles: Owner, Admin, Student.

## Pages
- index.html (landing)
- login.html (login)
- student.html
- admin.html
- owner.html

## Login
- Owner: owner / 1234
- Admin: admin / 1234
- Student: student / 1234