// UI Apply on Load
window.onload = function () {
  const savedLogo = localStorage.getItem("siteLogo");
  const savedWallpaper = localStorage.getItem("siteWallpaper");

  if (savedLogo) {
    const logos = document.querySelectorAll(".logo");
    logos.forEach(l => l.src = savedLogo);
  }
  if (savedWallpaper) {
    document.body.style.background = `url(${savedWallpaper}) no-repeat center center/cover`;
  }
};

// Logo Upload
document.addEventListener("DOMContentLoaded", () => {
  const logoInput = document.getElementById("uploadLogo");
  if (logoInput) {
    logoInput.addEventListener("change", (e) => {
      const file = e.target.files[0];
      if (file) {
        const reader = new FileReader();
        reader.onload = () => {
          const logoUrl = reader.result;
          localStorage.setItem("siteLogo", logoUrl);
          const logos = document.querySelectorAll(".logo");
          logos.forEach(l => l.src = logoUrl);
        };
        reader.readAsDataURL(file);
      }
    });
  }

  // Wallpaper Upload
  const wallpaperInput = document.getElementById("uploadWallpaper");
  if (wallpaperInput) {
    wallpaperInput.addEventListener("change", (e) => {
      const file = e.target.files[0];
      if (file) {
        const reader = new FileReader();
        reader.onload = () => {
          const wallpaperUrl = reader.result;
          localStorage.setItem("siteWallpaper", wallpaperUrl);
          document.body.style.background = `url(${wallpaperUrl}) no-repeat center center/cover`;
        };
        reader.readAsDataURL(file);
      }
    });
  }
});

// Reset UI
function resetUI() {
  localStorage.removeItem("siteLogo");
  localStorage.removeItem("siteWallpaper");
  document.querySelectorAll(".logo").forEach(l => l.src = "logo.png");
  document.body.style.background = `url("wallpaper.png") no-repeat center center/cover`;
}

// Fake login for now
function login() {
  alert("Login system to be implemented.");
}