/* CampusHub front-end logic (no backend yet) */
/* Persistence */
const DBKEY = 'campushub_v1';
const store = {
  read(){ try { return JSON.parse(localStorage.getItem(DBKEY)) || {}; } catch { return {}; } },
  write(d){ localStorage.setItem(DBKEY, JSON.stringify(d)); },
  get(k, f){ const d=this.read(); return d[k]===undefined?f:d[k]; },
  set(k,v){ const d=this.read(); d[k]=v; this.write(d); }
};

// Default accounts (demo)
const defaults = {
  students: [{u:'s', p:'123', name:'Student'}],
  admins: [{u:'a', p:'123', name:'Admin'}],
  owner: {u:'o', p:'123', name:'Owner'}
};
if(store.get('init')!==true){
  store.set('init', true);
  store.set('students', defaults.students);
  store.set('admins', defaults.admins);
  store.set('owner', defaults.owner);
  store.set('brand', { name:'CampusHub', primary:'#ff6600' });
  store.set('news', [
    {t:'Welcome to CampusHub', at: Date.now()-86400000},
    {t:'Inter-College Fest registrations open', at: Date.now()-3600000}
  ]);
  store.set('gallery', []); // {id, url, by, approved, votes, comments[], banned?}
  store.set('competitions', []); // {id, title, open: true, createdAt}
  store.set('appeals', []); // {name, roll, text, at}
}

// App Elements
const $ = (s, r=document)=>r.querySelector(s);
const $$ = (s, r=document)=>[...r.querySelectorAll(s)];
const routeLinks = $$('.nav a');
const routes = $$('.route');
const wallpaper = $('#wallpaper');
const brandLogo = $('#brandLogo');
const brandName = $('#brandName');
const year = $('#year'); year.textContent = new Date().getFullYear();

// Menu & Roles
const loginBtn = $('#loginBtn');
const userMenu = $('#userMenu');
const menuBtn = $('#menuBtn');
const menuSheet = $('#menuSheet');
const loginModal = $('#loginModal');
const ownerModal = $('#ownerModal');
const loginForm = $('#loginForm');
const loginError = $('#loginError');
const loginUser = $('#loginUser');
const loginPass = $('#loginPass');
const tabs = $$('.tabs button');
let currentRole = store.get('sessionRole', null);
let currentUser = store.get('sessionUser', null);

// Role toggles
function applyRoleUI(){
  // Show/hide elements by role
  $$('.role-student').forEach(el=> el.style.display = currentRole==='student' ? '' : 'none');
  $$('.role-admin').forEach(el=> el.style.display = currentRole==='admin' ? '' : 'none');
  $$('.role-owner').forEach(el=> el.style.display = currentRole==='owner' ? '' : 'none');
  // Menu visibility
  if(currentRole){ loginBtn.hidden = true; userMenu.hidden = false; }
  else { loginBtn.hidden = false; userMenu.hidden = true; }
  // Owner-only items in menu
  $$('.owner-only').forEach(el => el.style.display = currentRole==='owner' ? '' : 'none');
}
applyRoleUI();

/* Branding */
function applyBrand(){
  const brand = store.get('brand', {name:'CampusHub', primary:'#ff6600'});
  brandName.textContent = brand.name || 'CampusHub';
  document.documentElement.style.setProperty('--primary', brand.primary || '#ff6600');
  document.documentElement.style.setProperty('--overlay', brand.overlay || 0);
  wallpaper.style.backgroundImage = brand.wallpaper ? `url(${brand.wallpaper})` : `url(assets/wallpaper.jpg)`;
  if(brand.blur) wallpaper.style.filter = 'blur(6px)'; else wallpaper.style.filter = 'none';
  if(brand.logo) brandLogo.src = brand.logo;
}
applyBrand();

/* Navigation */
function go(route){
  routes.forEach(r => r.classList.remove('active'));
  $('#'+route).classList.add('active');
  routeLinks.forEach(a=> a.classList.toggle('active', a.dataset.route===route));
  window.scrollTo({top:0, behavior:'smooth'});
}
routeLinks.forEach(a=> a.addEventListener('click', (e)=>{ e.preventDefault(); go(a.dataset.route); }));

// Hero buttons open login with role pre-selected
$('#openStudent').addEventListener('click', ()=> openLogin('student'));
$('#openAdmin').addEventListener('click', ()=> openLogin('admin'));
$('#openOwner').addEventListener('click', ()=> openLogin('owner'));

/* Login */
function openLogin(role='student'){
  loginModal.hidden = false;
  tabs.forEach(b=> b.classList.toggle('active', b.dataset.tab===role));
  loginUser.value=''; loginPass.value=''; loginError.textContent='';
  loginForm.dataset.role = role;
}
$('#closeLogin').addEventListener('click', ()=> loginModal.hidden = true);
tabs.forEach(b => b.addEventListener('click', ()=> openLogin(b.dataset.tab)));

loginForm.addEventListener('submit', (e)=>{
  e.preventDefault();
  const role = loginForm.dataset.role;
  const u = loginUser.value.trim(); const p = loginPass.value;
  let ok = false, displayName = '';
  if(role==='student'){
    const list = store.get('students', []);
    const found = list.find(x => (x.u===u || x.email===u) && x.p===p);
    if(found){ ok=true; displayName=found.name || found.u; }
  } else if(role==='admin'){
    const list = store.get('admins', []);
    const f = list.find(x => x.u===u && x.p===p);
    if(f){ ok=true; displayName=f.name || f.u; }
  } else if(role==='owner'){
    const o = store.get('owner', {});
    if((o.u===u || o.email===u) && o.p===p){ ok=true; displayName=o.name || 'Owner'; }
  }
  if(!ok){ loginError.textContent = 'Invalid credentials'; return; }
  currentRole = role; currentUser = u;
  store.set('sessionRole', currentRole); store.set('sessionUser', currentUser);
  $('#userAvatar').src = store.get('brand',{}).logo || 'assets/logo.png';
  loginModal.hidden = true; applyRoleUI();
});

// Menu
menuBtn.addEventListener('click', (e)=>{
  e.stopPropagation();
  menuSheet.classList.toggle('open');
});
document.addEventListener('click', ()=> menuSheet.classList.remove('open'));
menuSheet.addEventListener('click', (e)=>{
  const btn = e.target.closest('button'); if(!btn) return;
  const action = btn.dataset.action;
  if(action==='logout'){ currentRole=null; currentUser=null; store.set('sessionRole', null); store.set('sessionUser', null); applyRoleUI(); }
  if(action==='settings' && currentRole==='owner'){ openOwner(); }
  if(action==='profile'){ alert('Profile screen is coming soon'); }
});

/* Owner Settings */
function openOwner(){ ownerModal.hidden = false; }
$('#closeOwner').addEventListener('click', ()=> ownerModal.hidden = true);
$('#setLogo').addEventListener('change', async (e)=>{
  const f = e.target.files[0]; if(!f) return;
  const data = await fileToDataURL(f); const b = store.get('brand',{}); b.logo=data; store.set('brand', b); applyBrand();
});
$('#setWallpaper').addEventListener('change', async (e)=>{
  const f = e.target.files[0]; if(!f) return;
  const data = await fileToDataURL(f); const b = store.get('brand',{}); b.wallpaper=data; store.set('brand', b); applyBrand();
});
$('#setPrimary').addEventListener('input', (e)=>{ const b=store.get('brand',{}); b.primary=e.target.value; store.set('brand', b); applyBrand(); });
$('#setBlur').addEventListener('change', (e)=>{ const b=store.get('brand',{}); b.blur=e.target.checked; store.set('brand', b); applyBrand(); });
$('#setOverlay').addEventListener('input', (e)=>{ const b=store.get('brand',{}); b.overlay=+e.target.value; store.set('brand', b); applyBrand(); });
$('#resetBrand').addEventListener('click', ()=>{ const b={name:'CampusHub', primary:'#ff6600'}; store.set('brand', b); applyBrand(); });

// Admin management
const adminList = $('#adminList');
function renderAdmins(){
  const list = store.get('admins', []);
  adminList.innerHTML = '';
  list.forEach((a,idx)=>{
    const li = document.createElement('li');
    li.innerHTML = `<span>@${a.u}</span><button data-i="${idx}" class="icon danger"><i class="fa-solid fa-user-xmark"></i></button>`;
    adminList.appendChild(li);
  });
  adminList.querySelectorAll('button').forEach(btn=> btn.addEventListener('click', ()=>{
    const i = +btn.dataset.i; const list = store.get('admins', []); list.splice(i,1); store.set('admins', list); renderAdmins();
  }));
}
renderAdmins();
$('#addAdminForm').addEventListener('submit', (e)=>{
  e.preventDefault();
  const u = $('#newAdminUser').value.trim(), p = $('#newAdminPass').value;
  if(!u || !p) return;
  const list = store.get('admins', []);
  if(list.find(x=>x.u===u)) { alert('Username exists'); return; }
  list.push({u,p,name:u}); store.set('admins', list); renderAdmins();
  e.target.reset();
});

/* Dashboard dynamic content */
function renderNews(){
  const ul = $('#newsList'); ul.innerHTML='';
  store.get('news', []).sort((a,b)=>b.at-a.at).slice(0,6).forEach(n=>{
    const li = document.createElement('li');
    li.innerHTML = `<span>${n.t}</span><span class="small">${timeAgo(n.at)}</span>`;
    ul.appendChild(li);
  });
}
function renderCompSummary(){
  const wrap = $('#compSummary'); wrap.innerHTML='';
  store.get('competitions', []).forEach(c=>{
    const el = document.createElement('span'); el.className='pill'; el.textContent = (c.open?'🟢 ':'🔒 ')+c.title;
    wrap.appendChild(el);
  });
}
function renderTrending(){
  const row = $('#trendingRow'); row.innerHTML='';
  const items = store.get('gallery', []).filter(g=>g.approved).sort((a,b)=> (b.votes||0)-(a.votes||0)).slice(0,10);
  items.forEach(i=>{
    const img = document.createElement('img'); img.className='thumb'; img.src = i.url; img.alt = i.by || 'student';
    row.appendChild(img);
  });
}
renderNews(); renderCompSummary(); renderTrending();

/* Gallery */
const galleryGrid = $('#galleryGrid');
function renderGallery(){
  const sort = $('#gallerySort').value;
  let items = store.get('gallery', []).filter(g=>g.approved);
  if(sort==='top') items = items.sort((a,b)=> (b.votes||0)-(a.votes||0));
  if(sort==='new') items = items.sort((a,b)=> (b.at||0)-(a.at||0));
  galleryGrid.innerHTML='';
  items.forEach(i=>{
    const div = document.createElement('div'); div.className='item';
    div.innerHTML = `
      <img src="${i.url}" alt="upload">
      <div class="meta">
        <span class="small">@${i.by||'student'}</span>
        <div class="actions-row">
          <button class="icon" data-like="${i.id}" title="Vote"><i class="fa-solid fa-heart"></i></button>
          <span class="badge">${i.votes||0}</span>
        </div>
      </div>`;
    galleryGrid.appendChild(div);
  });
  // Vote handlers (1 per competition in future; now per item)
  galleryGrid.querySelectorAll('[data-like]').forEach(btn=> btn.addEventListener('click', ()=>{
    if(!currentRole){ alert('Login as student to vote'); return; }
    const id = btn.dataset.like;
    const items = store.get('gallery', []);
    const item = items.find(x=>x.id===id);
    // basic per-item vote guard for demo
    const voted = store.get('voted', {});
    if(voted[id]){ alert('You already voted this item'); return; }
    item.votes = (item.votes||0)+1; store.set('gallery', items);
    voted[id] = true; store.set('voted', voted);
    renderGallery(); renderTrending();
  }));
}
$('#gallerySort').addEventListener('change', renderGallery);

// Student/Admin upload (goes to approval queue)
$('#uploadInput').addEventListener('change', async (e)=>{
  const f = e.target.files[0]; if(!f) return;
  const url = await fileToDataURL(f);
  const items = store.get('gallery', []);
  items.push({id: uid(), url, by: currentUser||'student', at: Date.now(), approved: (currentRole!=='student')});
  store.set('gallery', items);
  alert(currentRole==='student' ? 'Submitted for approval' : 'Uploaded & visible');
  renderGallery(); renderTrending();
});

/* Competitions */
const compList = $('#compList');
function renderCompetitions(){
  const comps = store.get('competitions', []);
  compList.innerHTML='';
  comps.forEach(c=>{
    const div = document.createElement('div'); div.className='card';
    div.innerHTML = `<div class="card-head"><h3>${c.title}</h3><span class="badge">${c.open?'Open':'Closed'}</span></div>
      <div class="actions-row">
        <button class="btn" data-view="${c.id}"><i class="fa-solid fa-eye"></i> View</button>
        <button class="btn" data-toggle="${c.id}">${c.open?'Close':'Open'}</button>
        <button class="btn danger role-owner" data-del="${c.id}"><i class="fa-solid fa-trash"></i></button>
      </div>`;
    compList.appendChild(div);
  });
  compList.querySelectorAll('[data-toggle]').forEach(b=> b.addEventListener('click', ()=>{
    if(currentRole!=='admin' && currentRole!=='owner') return alert('Admins only');
    const id = b.dataset.toggle; const comps = store.get('competitions', []); const c = comps.find(x=>x.id===id);
    c.open = !c.open; store.set('competitions', comps); renderCompetitions(); renderCompSummary();
  }));
  compList.querySelectorAll('[data-del]').forEach(b=> b.addEventListener('click', ()=>{
    if(currentRole!=='owner') return alert('Owner only');
    const id = b.dataset.del; const comps = store.get('competitions', []).filter(x=>x.id!==id); store.set('competitions', comps); renderCompetitions(); renderCompSummary();
  }));
}
renderCompetitions();

$('#btnNewComp').addEventListener('click', ()=>{
  if(currentRole!=='admin' && currentRole!=='owner') return alert('Admins/Owner only');
  const title = prompt('Competition title'); if(!title) return;
  const comps = store.get('competitions', []);
  comps.push({id: uid(), title, open:true, createdAt: Date.now()});
  store.set('competitions', comps); renderCompetitions(); renderCompSummary();
});

/* Messages (Appeals) */
$('#appealForm').addEventListener('submit', (e)=>{
  e.preventDefault();
  const name = $('#appealName').value.trim();
  const roll = $('#appealRoll').value.trim();
  const text = $('#appealText').value.trim();
  if(!name || !text) return;
  const list = store.get('appeals', []);
  list.push({name, roll, text, at: Date.now()});
  store.set('appeals', list);
  e.target.reset(); renderAppeals(); alert('Sent. Owner/Admin will review.');
});
function renderAppeals(){
  const ul = $('#appealList'); ul.innerHTML='';
  store.get('appeals', []).sort((a,b)=>b.at-a.at).forEach(a=>{
    const li = document.createElement('li');
    li.innerHTML = `<div>
      <div><strong>${a.name}</strong> <span class="small">(${a.roll||'n/a'})</span></div>
      <div class="small">${a.text}</div>
    </div>
    <span class="small">${timeAgo(a.at)}</span>`;
    ul.appendChild(li);
  });
}
renderAppeals();

/* Utilities */
function fileToDataURL(file){
  return new Promise((res, rej)=>{
    const r = new FileReader(); r.onload = ()=> res(r.result); r.onerror = rej; r.readAsDataURL(file);
  });
}
function uid(){ return Math.random().toString(36).slice(2,9); }
function timeAgo(t){
  const s = Math.max(1, Math.floor((Date.now()-t)/1000));
  const m = Math.floor(s/60), h = Math.floor(m/60), d = Math.floor(h/24);
  if(d>0) return d+'d ago'; if(h>0) return h+'h ago'; if(m>0) return m+'m ago'; return s+'s ago';
}

/* Initial gallery render */
renderGallery();

/* Demo owner lock (lightweight) — can be upgraded server-side later */
// Hidden watermark in console to discourage copy-paste reuse
console.log('%c Built for CampusHub by Astron Dice Ansh ', 'background:#ff6600;color:#fff;padding:4px 8px;border-radius:6px');
