
// Simple frontend that calls backend APIs (works when backend deployed to same origin)
async function fetchJSON(url){ try{ const r=await fetch(url); return r.json(); }catch(e){ return []; } }
async function load(){ document.getElementById('newsList').textContent='Loading...'; const news=await fetchJSON('/api/news'); const nwrap=document.getElementById('newsList'); nwrap.innerHTML=''; news.forEach(n=>{ const d=document.createElement('div'); d.className='card'; d.innerHTML=`<div><b>${n.title}</b><div class=tag>${new Date(n.ts).toLocaleString()}</div></div><div style="flex:1">${n.body||''}</div>`; nwrap.appendChild(d); });
  const gallery = await fetchJSON('/api/gallery'); const gw = document.getElementById('galleryList'); gw.innerHTML=''; gallery.forEach(g=>{ const c=document.createElement('div'); c.className='card'; c.innerHTML=`<img src="${g.url}"><div><b>${g.title}</b><div class="tag">Votes: ${g.votes||0}</div></div>`; gw.appendChild(c); });
  const comps = await fetchJSON('/api/comp'); const cw=document.getElementById('compList'); cw.innerHTML=''; comps.forEach(c=>{ const it=document.createElement('div'); it.className='card'; it.innerHTML=`<div style="font-size:20px">${c.emoji||'🏆'}</div><div><b>${c.title}</b><div class="tag">Ends: ${new Date(c.expires||0).toLocaleDateString()}</div></div>`; cw.appendChild(it); });
}
window.addEventListener('DOMContentLoaded', load);
