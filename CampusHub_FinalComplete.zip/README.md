
CampusHub — Complete package (Frontend + Backend)

Quick start (local):
1. unzip and cd into the project folder
2. npm install
3. npm run migrate   # creates SQLite DB and seeds owner/admin/student
4. npm start
5. Open http://localhost:3000

Default seeded accounts (Local):
- Owner: owner / campushub
- Admin: admin / 123
- Student: student / 123

Deploy:
- Push to GitHub.
- Deploy backend (server/) on Render/Railway (Node app).
- Serve frontend (public/) via GitHub Pages or from the same backend.
