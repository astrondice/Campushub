
const express = require('express');
const path = require('path');
const multer = require('multer');
const Database = require('better-sqlite3');
const bcrypt = require('bcrypt');
const cors = require('cors');
const { v4: uuid } = require('uuid');
const app = express();
app.use(express.json());
app.use(cors());

const DATA = path.join(__dirname, 'data.db');
const db = new Database(DATA);

// static front
app.use('/', express.static(path.join(__dirname, '..', 'public')));

// uploads setup
const UP = path.join(__dirname, '..', 'uploads');
const storage = multer.diskStorage({
  destination: function (req, file, cb) { cb(null, UP) },
  filename: function (req, file, cb) { cb(null, Date.now() + '-' + file.originalname) }
});
const upload = multer({ storage: storage });

// helpers
function uid(){ return 'id_'+Math.random().toString(36).slice(2,9); }
function now(){ return Date.now(); }

// Auth
app.post('/api/login', (req, res) => {
  const { role, id, pass } = req.body;
  const user = db.prepare('SELECT * FROM users WHERE (username = ? OR email = ?) AND role = ?').get(id, id, role);
  if(!user) return res.status(401).json({ok:false, msg:'User not found'});
  if(user.bannedUntil && user.bannedUntil > Date.now()) return res.status(403).json({ok:false, msg:'Banned'});
  const match = bcrypt.compareSync(pass, user.pass);
  if(!match) return res.status(401).json({ok:false, msg:'Wrong password'});
  const safe = { id: user.id, role: user.role, name: user.name, username: user.username, email: user.email, meta: user.meta, avatar: user.avatar };
  res.json({ok:true, user: safe});
});

app.post('/api/signup', (req, res) => {
  const { name, username, email, pass, meta } = req.body;
  const id = uuid();
  const hashed = bcrypt.hashSync(pass, 10);
  try {
    db.prepare('INSERT INTO users (id, role, username, email, pass, name, meta) VALUES (?, ?, ?, ?, ?, ?, ?)')
      .run(id, 'student', username, email, hashed, name, meta);
    res.json({ok:true, id});
  } catch(e){
    res.status(400).json({ok:false, msg: e.message});
  }
});

// upload to pending
app.post('/api/upload', upload.single('file'), (req, res) => {
  const { title, desc, userId } = req.body;
  if(!req.file) return res.status(400).json({ok:false, msg:'File missing'});
  const fileUrl = '/uploads/' + req.file.filename;
  const id = uuid();
  db.prepare('INSERT INTO pending (id, title, url, userId, ts, desc) VALUES (?, ?, ?, ?, ?, ?)')
    .run(id, title, fileUrl, userId, Date.now(), desc);
  res.json({ok:true, id});
});

app.get('/api/gallery', (req, res) => {
  const items = db.prepare('SELECT * FROM gallery ORDER BY ts DESC').all();
  res.json(items);
});

app.get('/api/pending', (req, res) => {
  const items = db.prepare('SELECT * FROM pending ORDER BY ts DESC').all();
  res.json(items);
});

app.post('/api/approve', (req, res) => {
  const { id } = req.body;
  const item = db.prepare('SELECT * FROM pending WHERE id = ?').get(id);
  if(!item) return res.status(404).json({ok:false, msg:'Not found'});
  db.prepare('INSERT INTO gallery (id, title, url, userId, approved, ts) VALUES (?, ?, ?, ?, ?, ?)')
    .run(item.id, item.title, item.url, item.userId, 1, Date.now());
  db.prepare('DELETE FROM pending WHERE id = ?').run(id);
  res.json({ok:true});
});

app.post('/api/news', (req, res) => {
  const { title, body, authorId } = req.body;
  const id = uuid();
  db.prepare('INSERT INTO news (id, title, body, authorId, ts) VALUES (?, ?, ?, ?, ?)').run(id, title, body, authorId, Date.now());
  res.json({ok:true, id});
});

app.get('/api/news', (req, res) => {
  res.json(db.prepare('SELECT * FROM news ORDER BY ts DESC').all());
});

app.post('/api/comp', (req, res) => {
  const { title, emoji, expires } = req.body;
  const id = uuid();
  db.prepare('INSERT INTO competitions (id, title, emoji, expires, created, active) VALUES (?, ?, ?, ?, ?, 1)')
    .run(id, title, emoji || '🏆', expires || 0, Date.now());
  res.json({ok:true, id});
});

app.get('/api/comp', (req, res) => res.json(db.prepare('SELECT * FROM competitions ORDER BY created DESC').all()));

app.post('/api/vote', (req, res) => {
  const { compId, userId, photoId } = req.body;
  const existing = db.prepare('SELECT * FROM votes WHERE compId = ? AND userId = ?').get(compId, userId);
  if(existing) return res.status(400).json({ok:false, msg:'Already voted'});
  db.prepare('INSERT INTO votes (id, compId, userId, photoId, ts) VALUES (?, ?, ?, ?, ?)').run(uuid(), compId, userId, photoId, Date.now());
  db.prepare('UPDATE gallery SET votes = votes + 1 WHERE id = ?').run(photoId);
  res.json({ok:true});
});

app.post('/api/appeal', (req, res) => {
  const { userId, message } = req.body;
  db.prepare('INSERT INTO appeals (id, userId, message, ts) VALUES (?, ?, ?, ?)').run(uuid(), userId, message, Date.now());
  res.json({ok:true});
});

app.get('/api/appeals', (req, res) => res.json(db.prepare('SELECT * FROM appeals ORDER BY ts DESC').all()));

app.get('/api/users', (req, res) => res.json(db.prepare('SELECT id, role, username, name, email, meta, bannedUntil FROM users').all()));

app.post('/api/ban', (req, res) => {
  const { userId, minutes } = req.body;
  const until = Date.now() + (minutes||10)*60*1000;
  db.prepare('UPDATE users SET bannedUntil = ? WHERE id = ?').run(until, userId);
  res.json({ok:true});
});

app.post('/api/unban', (req, res) => {
  const { userId } = req.body;
  db.prepare('UPDATE users SET bannedUntil = 0 WHERE id = ?').run(userId);
  res.json({ok:true});
});

app.use('/uploads', express.static(path.join(__dirname, '..', 'uploads')));

app.use((req,res)=> res.sendFile(path.join(__dirname, '..', 'public', 'index.html')));

const PORT = process.env.PORT || 3000;
app.listen(PORT, ()=> console.log('Server running on', PORT));
