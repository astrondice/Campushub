
const Database = require('better-sqlite3');
const path = require('path');
const dbPath = path.join(__dirname, '..', 'data.db');
const db = new Database(dbPath);

db.exec(`
CREATE TABLE IF NOT EXISTS users (
  id TEXT PRIMARY KEY,
  role TEXT,
  username TEXT UNIQUE,
  email TEXT,
  pass TEXT,
  name TEXT,
  meta TEXT,
  avatar TEXT,
  bannedUntil INTEGER DEFAULT 0
);

CREATE TABLE IF NOT EXISTS news (
  id TEXT PRIMARY KEY,
  title TEXT,
  body TEXT,
  authorId TEXT,
  ts INTEGER
);

CREATE TABLE IF NOT EXISTS gallery (
  id TEXT PRIMARY KEY,
  title TEXT,
  url TEXT,
  userId TEXT,
  approved INTEGER DEFAULT 0,
  ts INTEGER,
  votes INTEGER DEFAULT 0
);

CREATE TABLE IF NOT EXISTS pending (
  id TEXT PRIMARY KEY,
  title TEXT,
  url TEXT,
  userId TEXT,
  ts INTEGER,
  desc TEXT
);

CREATE TABLE IF NOT EXISTS competitions (
  id TEXT PRIMARY KEY,
  title TEXT,
  emoji TEXT,
  expires INTEGER,
  created INTEGER,
  active INTEGER DEFAULT 1
);

CREATE TABLE IF NOT EXISTS votes (
  id TEXT PRIMARY KEY,
  compId TEXT,
  userId TEXT,
  photoId TEXT,
  ts INTEGER
);

CREATE TABLE IF NOT EXISTS appeals (
  id TEXT PRIMARY KEY,
  userId TEXT,
  message TEXT,
  ts INTEGER,
  resolved INTEGER DEFAULT 0
);

CREATE TABLE IF NOT EXISTS logs (
  id TEXT PRIMARY KEY,
  action TEXT,
  meta TEXT,
  ts INTEGER
);
`);

const { v4: uuid } = require('uuid');
const bcrypt = require('bcrypt');

function insertUser(id, role, username, pass, name){ 
  const hashed = bcrypt.hashSync(pass, 10);
  const stmt = db.prepare('INSERT OR IGNORE INTO users (id, role, username, pass, name) VALUES (?, ?, ?, ?, ? )');
  stmt.run(id, role, username, hashed, name);
}

insertUser(uuid(), 'owner', 'owner', 'campushub', 'Owner');
insertUser(uuid(), 'admin', 'admin', '123', 'Admin');
insertUser(uuid(), 'student', 'student', '123', 'Student');
console.log('Database initialized at', dbPath);
db.close();
